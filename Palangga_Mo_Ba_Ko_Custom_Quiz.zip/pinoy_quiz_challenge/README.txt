PALANGGA MO BA KO? — CUSTOM TWO-PLAYER LOVE QUIZ

Features:
- Player 1 can create as many custom questions as desired before passing the phone.
- Each question has four answer choices, a correct-answer selector, and an optional sweet message.
- Player 2 answers the complete set one question at a time.
- A large crying-cat overlay appears in the center for a wrong answer.
- Sound effects and your supplied photo background.
- The old 100-question Filipino quiz mode has been removed from the playable menu.

HOW TO PLAY ON ANDROID
1. Download Palangga_Mo_Ba_Ko_Custom_Quiz.zip.
2. Open it in ZArchiver and choose Extract.
3. Open the extracted folder and tap index.html.
4. If needed, open it with an HTML viewer/browser that supports local HTML files.
5. Player 1 taps Create Your Love Quiz, fills in a question and four choices, selects the correct choice, and taps Add This Question.
6. Repeat for every question. When finished, tap Finish & Pass to Player 2.
7. Player 2 answers each question and taps Next Question to continue.

This is an HTML game source, not a compiled APK. Audio may require tapping the sound button first.
