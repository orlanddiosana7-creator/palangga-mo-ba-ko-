PALANGGA MO BA KO? — MULTIPLAYER UPDATE
========================================

WHAT THIS UPDATE ADDS
- Player 1 creates custom questions and a six-character room code.
- Player 2 joins on another phone with that code.
- Player 1 starts and advances the quiz.
- Player 2 answers on their own phone.
- Wrong answers trigger the crying-cat overlay and sound.

IMPORTANT
This version needs a Firebase Realtime Database project before online multiplayer can work.
Do not upload the placeholder Firebase config and expect multiplayer to work yet.

SETUP ON ANDROID
1. Go to https://console.firebase.google.com/ and sign in with Google.
2. Create a project (for example: palangga-mo-ba-ko). You can disable Google Analytics.
3. In the project, open Build > Realtime Database and create a database.
4. For initial testing only, select test mode if prompted. Test mode rules are temporary and allow public access. Do not store private information and do not use open rules for a public/production app.
5. In Project settings (gear icon) > General, add a Web app (</> icon) if you have not already. Register it with any nickname.
6. Copy the Firebase web configuration shown on screen.
7. Download/open this index.html as text in a code editor. Find:
   const firebaseConfig = {
   Replace the PASTE_... placeholder values with the matching values from your Firebase web config. Keep the quotes and commas.
   The databaseURL value must be the exact database URL shown by Firebase; it may not follow the default URL pattern in every region.
8. Save index.html.
9. Upload the updated index.html to your GitHub repository, replacing the old index.html at the repository root. Commit changes.
10. Wait for GitHub Pages to redeploy, then open your published site on both phones.

REALTIME DATABASE RULES FOR INITIAL TESTING ONLY
If you chose locked mode, the following rules allow read/write access for a quick private prototype, but they are NOT secure for a public launch and should not be left enabled long-term:

{
  "rules": {
    "rooms": {
      "$room": {
        ".read": true,
        ".write": true
      }
    }
  }
}

Never store passwords, addresses, or sensitive personal information in this demo. Anyone who knows/guesses a room code may be able to access its room when these rules are open. Room codes are intended only for casual testing. For a real public app, add Firebase Authentication and restrictive security rules/server-side answer checking.

HOW TO PLAY
1. Phone 1 opens the website, taps Create Your Love Quiz, adds one or more questions and answer options, then taps Create Online Room.
2. Phone 1 shares the six-character room code.
3. Phone 2 opens the same website, taps Join Partner's Room, enters the code, and taps Join Room.
4. Phone 1 taps Start Quiz. Phone 2 chooses answers. Phone 1 taps Next Question between questions.

If you need to return to single-phone play, use "Finish & Pass on This Phone".
